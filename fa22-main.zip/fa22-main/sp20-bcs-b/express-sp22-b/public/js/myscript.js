console.log("From Js File");

//this is a client side code
//this will not be executd on server
